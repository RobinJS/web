define(function(require){
    var PIXI        = require("libs/pixi");
    var config      = require("config");
    var Button      = require("button");

    var Game = function(deck){
        PIXI.DisplayObjectContainer.call(this);
        this.deck = deck;
        this.cards = [];

        this.playerBG = this.addChild(new PIXI.Sprite.fromImage(config.stageImages.playerBG));
        this.playerBG.anchor = new PIXI.Point(1.0, 0.5);
        this.playerBG.x = config.canvas.width - 40;
        this.playerBG.y = 374;

        this.buttons = {
            double   : this.addChild(new Button(config.buttons.double)),
            half     : this.addChild(new Button(config.buttons.half)),
            pass     : this.addChild(new Button(config.buttons.pass))
        };

        this.x = this.hiddenX = config.canvas.width;

        this.collectMotionData = Object.create(config.deck.pilePosition);
        this.collectMotionData.x += 1;
        this.collectMotionData.y += 1;

    };

    Game.prototype = Object.create(PIXI.DisplayObjectContainer.prototype);

    Game.prototype.show = function(callback){
        TweenMax.to(this, 0.5, {
            "x":0,
            "onComplete":callback
        });
    };

    Game.prototype.hide = function(callback){
        TweenMax.to(this, 0.5, {
            "x": this.hiddenX,
            "onComplete":callback
        });
    };

    Game.prototype.enableButtons = function(callback){
        var that = this;
        function callbackWrapper(m){
            that.buttons.double.events.click.remove(callbackWrapper);
            that.buttons.half.events.click.remove(callbackWrapper);
            that.buttons.pass.events.click.remove(callbackWrapper);
            callback && callback(m);
        }
        this.buttons.double.events.click.addOnce(callbackWrapper);
        this.buttons.half.events.click.addOnce(callbackWrapper);
        this.buttons.pass.events.click.addOnce(callbackWrapper);

        this.buttons.pass.enable();
        this.buttons.half.enable();
        this.buttons.double.enable();
    };

    Game.prototype.disableButtons = function(){
        this.buttons.half.disable();
        this.buttons.double.disable();
        this.buttons.pass.disable();
    };

    Game.prototype.collectCards = function(callback){
        var that = this;
        this.cards.forEach(function(card, index){
            if (index === that.cards.length-1){
                card.collect(function(){
                    that.removeChild(card);
                    callback && callback();
                });
            } else {
                card.collect(function(){
                    that.removeChild(card);
                });
            }
        });
    };

    Game.prototype.dealCards = function(callback){
        var that = this,
            choices = config.player.choices;

        if ( that.deck.currentAvailableCards.length < choices ) {
            choices = that.deck.currentAvailableCards.length;
        }

        this.cards = [];

        Array.apply(null, Array(choices)).map(function (card, index){
            // http://stackoverflow.com/a/10050831/3345926
            setTimeout(function(){
               

                if (index === choices-1){
                    card = that.addChild(that.deck.dealPlayerCards(index, callback));
                } else {
                    card = that.addChild(that.deck.dealPlayerCards(index));
                }
                that.cards.push(card);
            }, index*300);
        });
    };

    Game.prototype.revealOnPick = function(onPick, callback){
        var that = this;
        function chooseWrapper(chosenCard){
            onPick && onPick();
            that.chosenCard = that.cards.splice(that.cards.indexOf(chosenCard), 1)[0];
            that.chosenCard.alpha = 1;

            that.chosenCard.reveal(function(){
                that.cards.forEach(function(card, index){
                    card.disable(chooseWrapper);
                });
                callback && callback();
            });

            that.cards.push(that.chosenCard);
        };
        this.cards.forEach(function(card){
            card.enable(chooseWrapper);
        });
    };

    Game.prototype.reveal = function(callback){
        var that = this;
        that.cards.forEach(function(card, index){
            setTimeout(function(){
                if (index === that.cards.length-1){
                    card.alpha = 0.7;
                    callback && callback();
                } else {
                    card.reveal(function(){
                        card.alpha = 0.7;
                    });
                }
            }, index*300);
        });
    };

    Game.prototype.returnPlayerCardsToDeck = function(){
        var that = this;
        that.cards.forEach(function(card){
            that.deck.returnCard( card );
        });
    };

    Game.prototype.getCardValue = function(){
        return this.chosenCard.getValue();
    };

    Game.prototype.startHighlights = function(){
        this.tweens = TweenMax.fromTo(this.cards,0.1,{alpha:1.0},{alpha:0.7}).yoyo(true).repeat(7);
    };

    return Game;

});
