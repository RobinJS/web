define(function(require){
    var PIXI        = require("libs/pixi");
    var Background  = require("background");
    var Deck        = require("deck");
    var Game        = require("game");
    var Dealer      = require("dealer");
    var Account     = require("account");
    var config      = require("config");
    var Question    = require("questionHolder");
    var Messages    = require("messages");

    var STATES = {
        INIT            :0,
        PREPARE_TABLE   :1,
        DEAL            :2,
        BET_CHOICE      :3,
        CARD_PICKING    :4,
        CALC_RESULT     :5,
        COLLECT_CARDS   :6,
    };

    var App = function(){
        PIXI.DisplayObjectContainer.call(this);

        this.question = question = this.addChild(new Question());
        this.background = this.addChild(new Background());
        this.messages = this.addChild(new Messages());

        this.deck = new Deck();
        this.dealer = this.addChild(new Dealer(this.deck));
        this.game = this.addChild(new Game(this.deck));

        this.players = [
            this.addChild(new Account({balance:1000, bet:10, name: 'Player 1'})),
            this.addChild(new Account({balance:500, bet:10, name: 'Player 2'}))
        ];

        this.playerIndex = 0;
    };

    App.prototype = Object.create(PIXI.DisplayObjectContainer.prototype);
    App.STATES = STATES;

    App.prototype.setState = function(state){
        var that = this;
        console.log("-->entering state:", Object.keys(STATES)[state]);
        switch (state){
            case STATES.INIT:
                that.question.show(function(){
                    that.messages.setText("CHOOSE ANWSER!");
                    that.question.buttons.yes.events.click.addOnce(function(){
                        that.messages.setText("");
                        that.question.disableButtons();
                        that.setState(STATES.PREPARE_TABLE);
                    })
                    that.question.enableButtons();
                });
            break;
            case STATES.PREPARE_TABLE:
                that.question.hide(function(){
                    that.dealer.show(function(){
                        that.game.show(function(){
                            that.setState(STATES.DEAL);
                        });
                    });
                });
            break;
            case STATES.DEAL:
                that.players[that.playerIndex].show();
                that.dealer.dealCard(function(){
                    that.game.dealCards(function(){
                        that.setState(STATES.CARD_PICKING);
                    });
                });
            break;
            case STATES.BET_CHOICE:
                that.messages.setText("CHOOSE YOUR BET!");
                that.game.enableButtons(function(mult){
                    that.messages.setText("");
                    that.game.disableButtons();

                    if ( mult === 0 ) {
                        that.game.chosenCard.hide(function(){
                            that.setState(STATES.COLLECT_CARDS);
                        });
                        that.game.returnPlayerCardsToDeck();
                        that.dealer.returnCardToDeck();
                    } else {
                        that.players[that.playerIndex].placeBet(mult);
                        that.dealer.reveal(function(){
                            that.game.reveal(function(){
                                that.setState(STATES.CALC_RESULT);
                            });
                        });
                    }
                });
            break;
            case STATES.CARD_PICKING:
                that.game.startHighlights();
                that.messages.setText("PICK A GREATER CARD TO WIN!");
                that.game.revealOnPick(function(){
                    that.messages.setText("");
                }, function(){
                    that.setState(STATES.BET_CHOICE);
                });
            break;
            case STATES.CALC_RESULT:
                if (that.game.getCardValue() === that.dealer.getCardValue()){
                    that.messages.setText("IT'S A TIE, TRY AGAIN!");
                    that.players[that.playerIndex].updateTie();
                } else if (that.game.getCardValue() > that.dealer.getCardValue()){
                    that.messages.setText("CONGRATULATIONS, YOU WON!");
                    that.players[that.playerIndex].updateWin();
                } else {
                    that.messages.setText("YOU LOST, BETTER LUCK NEXT TIME!");
                }
                setTimeout(function(){
                    that.setState(STATES.COLLECT_CARDS);
                }, 1500);
            break;
            case STATES.COLLECT_CARDS:
                that.dealer.collectCard();
                that.game.collectCards(function(){

                    that.players[that.playerIndex].hide();
                    that.playerIndex = that.playerIndex === 0 ? 1 : 0;

                    console.log("end of round. cards left:", that.deck.currentAvailableCards.length );

                    if ( that.deck.currentAvailableCards.length < 2 ) {
                        that.messages.setText("END OF ROUND. PREPARING NEW DECK.");
                        that.deck.resetDeck();
                        setTimeout(function(){
                            that.setState(STATES.DEAL);
                        }, 1500);
                    } else {
                        that.setState(STATES.DEAL);
                    }
                });
            break;
            default:
            throw "missing state:" + Object.keys(STATES)[state];
        }
    };

    return App;
});
